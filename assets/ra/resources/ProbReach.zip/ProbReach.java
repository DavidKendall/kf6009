/* ProbReach.java
 * This java application computes the probability of reaching a set T of
 *   states of a discrete-time Markov chain starting from states in the DTMC.
 * Up to 64 states are supported. T is specified as a long integer: bit n = 1
 *   means state n is in T. 
 * The app returns a vector with an entry for each state in the model, giving
 *   the probability of reaching T eventually from that state.
 * There is an option to calculate bounded reachability: the vector gives, 
 *   each state, the probability of reaching T from that state in <= k steps.
 *
 * The program uses a fixed-point approach to calculating these probabilities,
 *   as outlined below.
 *
 * Let int n > 0; [0,1]^n is set of n-vectors of probability values;
 * [0,1]^n is partially ordered by (p_1 ... p_n) <= (q_1 ... q_n) iff
 *   for all 1 <= k <= n p_k <= q_k.
 * For functions F: [0,1]^n --> [0,1]^n, a fixed point is an 
 *   p = (p_1 ... p_n) such that F(p) = p.
 * A least fixed point of F is a fixed point p such that p <= p' for
 *   any other fixed pt p'.
 *
 * Let a discrete-time Markov chain be given, with n states S = {s_0, s_1, ...}
 *   & probability matrix P(i,j) (the transition probability from s_i to s_j).
 *
 * Let T be a set of states. F_T(): [0,1]^n --> [0,1]^n is the function defined
 * on vectors y of probabilities (indexed by states) by:
 *   F_T(y)_k = 1                   if s_k in T;
 *            | sum_{j} P(k,j) y_j  otherwise.
 *
 * The function leastFP(T) computes the least fixed point of F_T. The vector  
 *   x = (x_s)_{s in S} of probabilities it returns reports the probabilities
 *   of reaching a state in T from (each) state s.
 *
 * This  leastFP(T) is computed by applying F_T iteratively, starting from
 *   the zero vector: ie, x^(0) = (0,0,...) and, for k>0, x^(k+1) = F_T(x^(k)).
 *   Iteration proceeds until x^(k+1) agrees with x^(k) to within some pre-set
 *   tolerance, 'epsilon'.
 *
 * We get x^(0) <= x^(1) <= x^(2) <= ... with a limit, x, the least fixed
 *   point of F_T, equal within epsilon to the x^(k) at which iteration left
 *   off. As remarked, the component x_s is the probability that starting
 *   from state s, a state in T will eventually be reached.
 *
 * By simple inductive argument, it can also be seen that, for k >= 0, x(k+1)
 *   is the vector of /bounded/ reachability probabilities: the s-component
 *   is the probability of reaching T from s in <= k steps.
 *
 * The function bdPRch(k, T) runs the iterative computation as in leastFP(T)
 *   but for up to k iterations, returning x^(k) rather than x.
 *
 * Baier & Katoen suggest a more general fixed-point algorithm which computes
 *   a vector of /constained reachability/ probabilities: given two subsets of
 *   states, T, V, let F_TV be defined like F_T above, but on vectors of
 *   probabilities indexed by V (rather than the whole state space S).
 *   Then the leastFP function 'restricted' to V yields a vector of
 *   probabilities of reaching T by runs constained to be in states in V
 *   (think: V Until T rather than just <>T). The Baier & Katoen algorithm
 *   (see their theorem 10.15) is actually a slight generalisation of this.
 *
 * For programming convenience this app assumes <= 64 states and uses the
 *   1-bits of a (64-bit) long to specify T: n in T iff bit n is on.
 *
 * MJB April-May 2015 
 */
import java.io.*;
import java.util.Scanner;

public class ProbReach {
  private double[][] P; //probability matrix of underlying DTMC
  private int nSts;
  private static double epsilon;

  //Constructor expects a path to a file of n lines each containing n doubles
  public ProbReach(String pathToP) { this(pathToP, 1.0e-16); }

  public ProbReach(String pathToP, double epsln) {
    Scanner sc = null;
    String[] line = null;
    int r = 0;
    try {
      sc = new Scanner(new FileReader(pathToP));
      if (sc.hasNextLine()) {
        line = sc.nextLine().split("\\s+"); //split input line on whitespace
        nSts = line.length;
        if (nSts > 64) {
          System.err.println("Sorry: I work only with up to 64 states");
          System.exit(1);
        }
        P = new double[nSts][nSts];
        for (int c=0; c<nSts; c++) {
          P[r][c] = Double.parseDouble(line[c]);
        }
        r++;
      } else {
        System.err.println("Error: no data in probability data file");
        System.exit(1);
      }
      while (sc.hasNextLine()) {
        line = sc.nextLine().split("\\s+");
        for (int c=0; c<nSts; c++) {
          P[r][c] = Double.parseDouble(line[c]);
        }
        r++;
      } //end try
    } catch (IOException iox) {
      System.err.println("Could not read probability data file\n" + iox);
      System.exit(2);
    } catch (ArrayIndexOutOfBoundsException aiox) {
        System.err.println(
          "Error: wrong number of data in probability data file\n" + aiox);
        System.exit(3);
    } catch (NumberFormatException nfx) {
        System.err.println(
          "Error: wrong number of data in probability data file\n" + nfx);
        System.exit(4);
    }
    epsilon = epsln;
  } // end constructor

  public String toString() {
    StringBuilder sb = new StringBuilder();
    for (int r = 0; r < nSts; r++) {
      for (int c = 0; c < nSts; c++) {
        sb.append(String.format("%8.6f ", P[r][c]));
      }
      sb.append("\n");
    }
    return sb.toString();
  }

  public static String vecDisplay(String legend, double[] x) {
    StringBuilder sb = new StringBuilder(legend);
    for (int i = 0; i < x.length; i++) 
      sb.append(String.format("%12.10f ", x[i]));
    return sb.toString();
  }

  //Sum an array of doubles (eg a matrix row)
  private static double sum(double[] a) {
    double s = 0.0;
    for (int i=0; i<a.length; i++) s += a[i];
    return s;
  }

  //Rows are normalised, within epsilon
  public boolean rowsNormal() {
    boolean ok = true;
    double s = 0;
    for (int r = 0; r<nSts; r++) {
      s = sum(P[r]);
      if (Math.abs(s - 1) > epsilon) {
        System.out.printf("Row %d has sum %f\n", r, s);
        ok = false;
      }
    }
    return ok;
  }

  //Accessors
  public int  getNSts()  { return nSts; }

  public double[][] getP()  { return P;}

  public double getP(int r, int c) {
    if (r < nSts && c < nSts)
      return P[r][c];
    // else
    System.err.printf("%d,%d - index input P out of bounds");
    return -1;
  }

  public double getEpsilon()          { return epsilon; }
  public void   setEpsilon(double e)  { epsilon = e; }
   
  //Report whether state n is in state set T
  // (long integer: 1-bits specify state in set)
  public boolean isIn(int n, long T) { 
    if (n >= nSts) return false;
    //else
    return ((T & (1 << n)) != 0);
  }

  //cardinality of a state set
  public int card(long T) {
    int c = 0;
    long msk = 1;
    for (int i = 0; i < nSts; i++) {
      if ((T & msk) != 0) c++;
      msk <<= 1;
    }
    return c;
  }

  // Return a string listing a state set
  public String list(long T) {
    if (card(T) == 0)
      return "{}";
    //else
    StringBuilder sb = new StringBuilder("{");
    for (int i = 0; i < nSts; i++) {
      if (isIn(i, T))
        sb.append(String.format("%d,", i));
    }
    sb.deleteCharAt(sb.length()-1);
    sb.append("}");
    return sb.toString();
  }

  /* The function F determined by state-set T, of which we wish to find
   *   the least fixed point.
   * F maps vectors of probabilies (indexed by the states) to same. */
  public double[] F(double[] y, long T) {
    if (y.length != nSts) {
      System.err.printf("Probablity vector has wrong size: %d\n", y.length);
      return y;
    }
    double[] ny = new double[nSts];
    double pp;
    for (int i=0; i<nSts; i++) {
      if (isIn(i, T)) {
        ny[i] = 1;
      } else { //ny[i] = sum_j P[i][j].y[j]
        pp = 0.0;
        for (int j=0; j<nSts; j++) {
          pp += P[i][j] * y[j];
        }
        ny[i] = pp;
      }
    }
    return ny;
  } //end F(y,T)


  // Compute the least fixed point of F determined by T as above
  // For each state s, the probability of reaching T from s = the s-cpt
  //   of the vector returned by this computation.
  public double[] leastFP(long T) {
    double[] x = new double[nSts],
            nx = new double[nSts];
    for (int i=0; i<nSts; i++)
      x[i] = 0.0;

    int itnNo = 0;
    nx = F(x,T);
    while (diff(nx,x)) {
      itnNo++;
      System.out.printf("%d iterations\r", itnNo);
      x = nx;
      nx = F(x,T);
    }
    System.out.println();
    return x;
  } //end leastFP(T)

  //Is there significant difference between two probability vectors?
  //  (ie, can the lfp iteration terminate?)
  private boolean diff(double[] x, double[] y) {
    if (x.length != nSts || y.length != nSts) {
      System.err.printf("Warning: diff finds unexpected length(s): %d, %d\n",
        x.length, y.length);
    return true;
    }
    for (int i = 0; i<nSts; i++)
      if (Math.abs(x[i] - y[i]) >= epsilon)
        return true;
    //else
    return false;
  }

  //Bounded probabilistic reachability: ie reachability of T within k steps
  //  -like leastFP() but with termination after k iterations
  public double[] bdPRch(int k, long T) {
    double[] x = new double[nSts],
            nx = new double[nSts];
    for (int i=0; i<nSts; i++)
      x[i] = 0.0;

    int itnNo = 0;
    nx = F(x,T);
    while (itnNo < k && diff(nx,x)) {
      itnNo++;
      System.out.printf("%d iterations\r", itnNo);
      x = nx;
      nx = F(x,T);
    }
    System.out.println();
    return x;
  } //end bdPRch(k,T)

} //end class 
