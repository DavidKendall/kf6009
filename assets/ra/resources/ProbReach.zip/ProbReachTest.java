import java.util.Scanner;

public class ProbReachTest {
  public static void main(String[] args) {
    if (args.length < 2) {
      System.err.println("Usage: java ProbReachTest <path to probs> <tolerance>");
      return;
    }
    ProbReach app = null;
    try {
      app = new ProbReach(args[0], Double.parseDouble(args[1]));
    } catch (NumberFormatException x) {
      System.err.println("Bad number format; using default tolerance");
      app = new ProbReach(args[0]);
    }
    System.out.println(app);
    System.out.println(app.rowsNormal()? "ok": "not ok");

    Scanner in = new Scanner(System.in);
    long T = 0;
    System.out.print("Enter a state set as a (hex) long int; EoF to finish: ");
    while (in.hasNextLong(16)) {
      T = in.nextLong(16);
      System.out.printf("%d states in T:\n%s\n", app.card(T), app.list(T));
      System.out.println(app.vecDisplay("Reachability vector: ", app.leastFP(T)));
      System.out.print("Another state set (EoF to finish): ");
    }
    System.out.println("\nBye");
  }
}
