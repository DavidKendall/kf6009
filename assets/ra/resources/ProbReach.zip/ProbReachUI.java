/* ProbReachUI.java
 * A GUI for probabilistic least fixed-point computations.
 * See extended comment at head of ProbReach.java for summary of theory.
 *
 * The GUI is simple: 
 *   The probability matrix is read from a file given on the command line;
 *   Tolerance 'epsilon' is optionally given on command line (default = 1e-16). 
 *   A text box is provided for setting epsilon
 *   A text box allows setting bounded iteration (bounded reachability):
 *     set a positive integer here, or blank for unbounded iteration.
 *   Set T is specified as a long integer in hex format in text box.
 *     Remember 1-bits define T as a subset of state set S.
 *   A button, or ENTER in T text box, fires reachabilty/l.f.pt computation.
 *
 * Output is displayed in a scrollable text area: prob matrix, listings of
 *   state sets, reachability vectors, etc.
 *
 * MJB April-May 2015 
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;

public class ProbReachUI extends JFrame implements ActionListener {
  private JTextField txtEpsilon;
  private JTextField txtBound;
  private JTextField txtStateSetT;
  private JTextArea  display;
  private JButton btnDoReachbty;
  private ProbReach app;
  private int bound = -1; //-ve val => no bound

  //Constructors
  public ProbReachUI(String probData) { this(probData, 1.0e-16); }

  public ProbReachUI(String probData, double epsilon) {
    super("Least Fixedpoint Probabilistic Reachability - " + probData);
    txtEpsilon = new JTextField(String.format("%e", epsilon));
    txtBound = new JTextField(5);
    txtStateSetT = new JTextField(10);
    btnDoReachbty = new JButton("Do Reach'bty prob");

    JPanel topPnl = new JPanel();
    topPnl.add(new JLabel("Epsilon:")); topPnl.add(txtEpsilon);
    topPnl.add(new JLabel("Bound:")); topPnl.add(txtBound);
    topPnl.add(new JLabel("T:")); topPnl.add(txtStateSetT);
    topPnl.add(btnDoReachbty);
    add(topPnl, BorderLayout.NORTH);

    txtEpsilon.addActionListener(this);   txtBound.addActionListener(this);
    txtStateSetT.addActionListener(this); btnDoReachbty.addActionListener(this);

    display = new JTextArea(80, 20);
    display.setWrapStyleWord(true); display.setLineWrap(true);
    DefaultCaret caret = (DefaultCaret)display.getCaret(); //automatically
    caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);     //scroll on append
    add(new JScrollPane(
          display,
          ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
          ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER),
        BorderLayout.CENTER);

    setSize(900, 500);
    setVisible(true);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    app = new ProbReach(probData, epsilon);
    display.append(app.toString()+"\n");
    display.append(app.rowsNormal()? "ok\n": "not ok\n");
  }

  public void actionPerformed(ActionEvent evt) {
    Object src = evt.getSource();
    if (src == txtEpsilon) {
      updateEpsilon();
    } else if (src == txtBound) {
      updateBound();
    } else if (src == txtStateSetT || src == btnDoReachbty) {
      updateEpsilon();
      updateBound();
      doReachability();
    }
  } //end actionPerformed(...)

  //Helpers

  // Update tolerance value from text box contents.
  private void updateEpsilon() {
    try {
      double e = Double.parseDouble(txtEpsilon.getText());
      app.setEpsilon(e);
    } catch (NumberFormatException ex) {
      display.append(""+ex+"\n");
      txtEpsilon.setText(String.format("%e", app.getEpsilon()));
    }
  }

  //Get iteration bound (if set) from text box.
  //Negative bound = unbounded; this is always trhe case unless a value >= 0
  //  is entered.
  private void updateBound() {
    if (txtBound.getText().equals("")) {
      bound = -1;
      return;
    }
    try {
      bound = Integer.parseInt(txtBound.getText());
    } catch (NumberFormatException ex) {
      display.append(""+ex+"\n");
      txtBound.setText("");
      bound = -1;
    }
  }

  //Compute as appropriate EITHER fixed point (x, to within tolerance), giving
  //vector of probs of reaching state set from each state, OR a finitely
  //iterated approximation, giving vector of probs of reaching state set in
  //a bounded number of steps.
  private void doReachability() {
    try {
      long T = Long.parseLong(txtStateSetT.getText(), 16);
      display.append(String.format("%d states in T:\n%s\n",
                                 app.card(T), app.list(T)));
      double[] reachVec;
      if (bound < 0) { //unbounded
        reachVec = app.leastFP(T);
        display.append(app.vecDisplay("Unbd reachability vector: ", reachVec));
      } else {
        reachVec = app.bdPRch(bound, T);
        display.append(app.vecDisplay(
          String.format("%d-bounded reachability vector: ", bound), reachVec));
      }
      display.append("\n\n");
    } catch (NumberFormatException ex) {
      display.append(""+ex+"\n");
    }
  }

  public static void main(String[] args) {
    if (args.length == 0) {
      System.err.println("Usage: java ProbReachUI file [epsilon]");
      return;
    }
    if (args.length < 2)
      new ProbReachUI(args[0]);
    else {
      try {
        new ProbReachUI(args[0], Double.parseDouble(args[1]));
      } catch (NumberFormatException x) {
        System.err.println("Bad number format; using default epsilon");
        new ProbReachUI(args[0]);
      }
    }
  } //end main
}

