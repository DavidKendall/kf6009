/* GenZeroconf.java
 * Generate probability matrix for input toLFPProbs tool.
 * Output lines are rows of the matrix; they should be rdirected to a file. 
 *
 * Usage: java GenZeroconf nProbes nNodes probMsgLoss > tgtFile
 */
public class GenZeroconf {
  //Output to console the rows of the probability matrix for the zeroconf
  //  protocol. There are n+5 rows or n+5 entries making an (n+5)x(n+5) matrix.
  //n = no probes, m = no pre-existing nodes, p = prob of message loss
  static void genZeroconf(int n, int m, double p) {
    double q = (double)m/65024;

    System.out.printf("0.0 %f %s %f 0.0\n", q, zeros(n+1), 1.0-q);
    for (int k=1; k<=n; k++)
      System.out.printf("%f %s %f %s\n", 1.0-p, zeros(k), p, zeros(n+3-k));
    System.out.printf("%s 1.0 0.0 0.0\n", zeros(n+2));
    System.out.printf("%s 1.0 0.0 0.0\n", zeros(n+2));
    System.out.printf("%s 1.0\n", zeros(n+4));
    System.out.printf("%s 1.0\n", zeros(n+4));
  } 

  //Helper: return a string of r '0.0' separated by spaces  
  static String zeros(int r) {
    StringBuilder sb = new StringBuilder();
    for (int k=0; k<r; k++)
      sb.append("0.0 ");
    sb.deleteCharAt(sb.length()-1);
    return sb.toString();
  }

  public static void main(String[] args) {
    if (args.length < 3) {
      System.err.println(
        "Usage: java GenZeroconf nProbes nNodes probMsgLoss > tgtFile"); 
      return;
    }
    genZeroconf(Integer.parseInt(args[0]),
                Integer.parseInt(args[1]), Double.parseDouble(args[2]));
  }
}
